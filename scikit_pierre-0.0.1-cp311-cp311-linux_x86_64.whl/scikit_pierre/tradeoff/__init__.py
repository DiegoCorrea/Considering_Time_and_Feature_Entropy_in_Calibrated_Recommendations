"""
This file init the trade-off module
"""
