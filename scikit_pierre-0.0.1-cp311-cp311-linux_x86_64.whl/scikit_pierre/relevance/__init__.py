"""
This file init the relevance module.
"""
