"""
This file init the metric module.
"""
