"""
This file init the tradeoff weight module.
"""
