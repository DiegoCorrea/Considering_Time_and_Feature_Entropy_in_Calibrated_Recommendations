"""
This file init the measure module.
"""
