"""
Scikit-Pierre is a Scientific ToolKit for Post-processing Recommendations.
"""
